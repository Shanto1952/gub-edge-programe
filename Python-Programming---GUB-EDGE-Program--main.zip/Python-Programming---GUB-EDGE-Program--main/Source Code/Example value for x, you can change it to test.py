x = 5

if x < 2:
    print('Below 2')

elif x < 20:
    print('Below 20')

elif x < 10:
    print('Below 10')

else:
    print('Something else')


if x < 2:
    print('Below 2')

elif x >= 2:
    print('Two or more')

else:
    print('Something else')
