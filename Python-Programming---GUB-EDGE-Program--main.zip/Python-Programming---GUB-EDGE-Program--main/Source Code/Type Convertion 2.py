str = '32'

print(type(str))  # Its type will be <class 'str'>

c_str = int(str)

print(type(c_str))  # Its type will be <class 'int'>
