num=3
ans = bytes(num)
print(ans)