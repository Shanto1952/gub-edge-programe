Dict = {1: 'Geeks', 2: 'For', 3: 'Geeks'}
print(Dict)