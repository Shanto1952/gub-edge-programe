num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))

square = num1 ** 2
cube = num2 ** 3

sum_result = square + cube

print("Square of first number:", square)
print("Cube of second number:", cube)
print("Sum of square and cube:", sum_result)