number = int(input("Enter a number: "))

next_number = number + 1
previous_number = number - 1

print("Next number:", next_number)
print("Previous number:", previous_number)