i=0
while i < 10 :
  if (i%2==0):
    print(f"{i} even ")
  else:
    print(f"{i} odd ")

  i=i+1