for i in range(1, 10, 3):
  {
     print(i)

  }
