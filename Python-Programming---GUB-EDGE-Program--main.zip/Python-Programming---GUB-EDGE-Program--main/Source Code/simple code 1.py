for x in range(1, 11):

      if (x%2==0):
        print("your exam in A Bulding ")
      else:
        print("your exam in B Bulding ")