city = "Narayanganj"
code = 1461

code_str = str(code)

result = city + "-" + code_str

print(result)
