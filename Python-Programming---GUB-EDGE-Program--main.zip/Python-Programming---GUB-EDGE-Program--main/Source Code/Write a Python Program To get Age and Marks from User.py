age = int(input("Enter your age: "))
marks = int(input("Enter your marks: "))

if age >= 18 and 90 < marks < 100:
    print("You are selected!")
else:
    print("You are not selected.")