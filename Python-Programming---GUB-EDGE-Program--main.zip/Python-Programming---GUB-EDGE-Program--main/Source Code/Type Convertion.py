v1 = 3

print(type(v1))  # It will display <class 'int'>

v1 = v1 + 4.4

print(type(v1))  # It will display <class 'float'>