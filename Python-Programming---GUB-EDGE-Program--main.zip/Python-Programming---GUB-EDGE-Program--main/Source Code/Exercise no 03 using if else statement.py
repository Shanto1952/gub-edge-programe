
num = int(input("Enter a numbet: "))
if(num<0):
    print("Negative")
elif(num>0):
    print("Positive")
else:
    print("Zero")