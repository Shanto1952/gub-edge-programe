site_string = "jafricode.com"
byte = bytes(site_string, 'utf-8')
print(byte)