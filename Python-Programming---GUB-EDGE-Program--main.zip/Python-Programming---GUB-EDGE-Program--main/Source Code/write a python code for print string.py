str1= 'He Said , "I am Fine"\n'
str2= "He Said , \"I am Fine\"\n"

str3= 'He Said , \n\'I am Fine\''
print (str1)
print (str2)
print (str3)
