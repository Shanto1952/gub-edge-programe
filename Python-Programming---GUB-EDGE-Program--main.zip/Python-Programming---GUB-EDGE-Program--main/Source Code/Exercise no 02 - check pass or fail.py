
num = int(input("Enter a Number: "))
if(num<50):
    print("Fail")
else:
    print("Pass")