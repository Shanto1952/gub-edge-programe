
num = int(input("Enter an Number: "))
if(num%2==0):
    print("Even")
else:
    print("Odd")
