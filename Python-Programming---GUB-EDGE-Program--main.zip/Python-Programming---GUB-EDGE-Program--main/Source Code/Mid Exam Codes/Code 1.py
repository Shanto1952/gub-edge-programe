string = input("Enter a string: ")
print("Reversed string:", string[::-1])